<?php
/**
 * Emerald Ivoire: serves the pre-built pages from /site at their usual URLs.
 */
if (!defined('ABSPATH')) { exit; }

function emerald_site_dir() { return get_template_directory() . '/site/'; }

function emerald_fill($html) {
    return str_replace('%%T%%', get_template_directory_uri() . '/site', $html);
}

function emerald_request_path() {
    $path = trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
    $base = trim((string) parse_url(home_url('/'), PHP_URL_PATH), '/');
    if ($base !== '' && strpos($path, $base) === 0) {
        $path = trim(substr($path, strlen($base)), '/');
    }
    return $path;
}

function emerald_send($file, $type, $status = 200) {
    status_header($status);
    header('Content-Type: ' . $type . '; charset=utf-8');
    echo emerald_fill(file_get_contents($file));
    exit;
}

add_action('template_redirect', function () {
    if (is_admin() || is_preview() || is_search() || is_feed()) { return; }
    foreach (array('p', 'page_id', 's', 'preview', 'feed') as $q) {
        if (isset($_GET[$q])) { return; }
    }
    $path = emerald_request_path();
    $dir = emerald_site_dir();

    $files = array(
        'sitemap.xml'   => array('sitemap.xml', 'application/xml'),
        'llms.txt'      => array('llms.txt', 'text/plain'),
        'llms-full.txt' => array('llms-full.txt', 'text/plain'),
    );
    if (isset($files[$path])) {
        emerald_send($dir . $files[$path][0], $files[$path][1]);
    }
    if (!preg_match('~^[a-z0-9-]*$~', $path)) { return; }

    $page = $dir . 'pages/' . ($path === '' ? 'index' : $path) . '.html';
    if (is_file($page)) {
        emerald_send($page, 'text/html');
    }
    if (is_404()) {
        emerald_send($dir . 'pages/404.html', 'text/html', 404);
    }
}, 0);

/* robots.txt from the theme, so it lists the sitemap and allows AI crawlers */
add_filter('robots_txt', function ($output, $public) {
    $file = emerald_site_dir() . 'robots.txt';
    return ($public && is_file($file)) ? file_get_contents($file) : $output;
}, 99, 2);

/* the built pages carry their own sitemap; switch off the core one to avoid two */
add_filter('wp_sitemaps_enabled', '__return_false');

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('emerald-fonts', 'https://fonts.googleapis.com/css2?family=Bodoni+Moda:ital,opsz,wght@0,6..96,400;1,6..96,400&family=Figtree:wght@400;500;600&family=Pinyon+Script&display=swap', array(), null);
    wp_enqueue_style('emerald-site', get_template_directory_uri() . '/site/assets/css/style.css', array(), '1.0.0');
});
