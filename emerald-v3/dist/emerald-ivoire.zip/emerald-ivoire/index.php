<?php
/* Fallback for WordPress pages and posts that are not part of the built site. */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header class="site-header"><div class="wrap bar" style="grid-template-columns:1fr auto 1fr">
  <span></span>
  <a class="brand" href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo esc_url(get_template_directory_uri() . '/site/img/logo-dark.webp'); ?>" alt="Emerald Luxury Events" width="700" height="292"></a>
  <span></span>
</div></header>
<main class="section"><div class="wrap narrow">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <article>
    <h1><?php the_title(); ?></h1>
    <div class="text"><?php the_content(); ?></div>
  </article>
<?php endwhile; else : ?>
  <h1>Pagina nu există</h1>
  <p><a class="btn btn-green" href="<?php echo esc_url(home_url('/')); ?>">Pagina principală</a></p>
<?php endif; ?>
</div></main>
<?php wp_footer(); ?>
</body>
</html>
