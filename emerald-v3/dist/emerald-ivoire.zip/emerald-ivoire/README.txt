Emerald Ivoire – temă WordPress
================================

Instalare: Aspect → Teme → Adaugă temă → Încarcă temă → emerald-ivoire.zip → Instalează → Activează.
Necesar: Setări → Legături permanente = „Numele articolului” (/%postname%/).

Paginile sunt în site/pages/*.html și se servesc la adresele:
  /  /sapphire-ballroom/  /gold-ballroom/  /diamond-ballroom/  /salonul-gourmet/
  /terasa-emerald/  /gradina-emerald/  /emerald-boutique-hotel/  /servicii-all-inclusive/
  /nunti-targu-mures/  /botez-targu-mures/  /evenimente-corporate/  /galeria-foto-video/
  /despre-noi/  /contact/  /intrebari-frecvente/
plus /sitemap.xml, /robots.txt, /llms.txt, /llms-full.txt.

Textele se modifică în proiect (emerald-v3/_build/build.py), apoi se reconstruiește tema.
După activare, goliți cache-ul (dacă există un plugin de cache) și dezactivați sitemap-ul
din pluginul SEO, dacă există, ca să nu fie două sitemap-uri.
